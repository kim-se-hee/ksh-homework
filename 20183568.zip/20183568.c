#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
int main(int argc,char *argv[])
{
	if (argc != 2)
	{
		exit(1);
	}
	FILE *f = fopen(argv[1], "r");
	char *newf = "osparad.rev";
	FILE *g = fopen(newf, "w");
	int char_num = 0;
	int	word_num = 0;
	int	line_num = 0;
	int	ch;
	if (f == NULL)
	{
		printf("xxx");
		exit(1);
	}
	while ((ch = fgetc(f)) != EOF)
	{
		if (ch == ' ')
		{
			fprintf(g, "%c", ch);
			++word_num;
		}
		else if (ch == '\n')
		{
			fprintf(g, "%c", ch);
			++line_num;
		}
		else if (65 <= ch && ch <= 90)
		{
			fprintf(g, "%c", ch + 32);
			++char_num;
		}
		else if (97 <= ch && ch <= 122)
		{
			fprintf(g, "%c", ch - 32);
			++char_num;
		}
		else
			fprintf(g, "%c", ch);
	}
	printf("line count:\t\t%d\n", line_num);
	printf("word count:\t\t%d\n", word_num);
	printf("char count:\t\t%d\n", char_num);
	fclose(f);
	fclose(g);
	printf("����ߴ�");
	return 0;
}